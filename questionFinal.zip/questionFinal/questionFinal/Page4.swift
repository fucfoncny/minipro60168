//
//  page4.swift
//  questionFinal
//
//  Created by ict on 16/11/2561 BE.
//  Copyright © 2561 ict. All rights reserved.
//
import UIKit
import Foundation
import AVFoundation
class Page4: UIViewController{

    
    @IBOutlet weak var questionCounter: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var progressView: UIView!
    @IBOutlet weak var flagView: UIImageView!
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var showTime: UILabel!
    
    @IBOutlet weak var optionA: UIButton!
    @IBOutlet weak var optionB: UIButton!
    @IBOutlet weak var optionC: UIButton!
    @IBOutlet weak var optionD: UIButton!
    
    let allQuestions = QuestionBank()
    var questionNumber: Int = 0
    var score: Int = 0
    var selectedAnswer: Int = 0
    
    var timer = Timer()
    var timeCount = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateQuetion()
        updateUI()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(Page4.processTimer),userInfo: nil, repeats: true)
}
    @objc func processTimer() {
        if timeCount > 0 {
            timeCount -= 1
            showTime.text = String(timeCount)
        }else{
            timer.invalidate()
        }
        if timeCount <= 0 {
            timeCount=0
            showTime.text = String(timeCount)
        }
        showTime.text = String(timeCount)
    }
    @IBAction func answerPressed(_ sender: UIButton) {
        if timeCount > 0 {
        if sender.tag == selectedAnswer {
            print("correct")
            score += 1
            ProgressHUD.showSuccess("ถูกต้อง")
        }else{
            print("wrong")
            ProgressHUD.showError("ผิด")
        }
         questionNumber += 1
         
        updateQuetion()
            timeCount=11
        }
        
    }
    
    func updateQuetion(){
        
        
        if questionNumber < allQuestions.list.count{
            flagView.image = UIImage(named:(allQuestions.list[questionNumber].questionImage))
            questionLabel.text = allQuestions.list[questionNumber].question
            optionA.setTitle(allQuestions.list[questionNumber].optionA, for: UIControl.State.normal)
            optionB.setTitle(allQuestions.list[questionNumber].optionB, for: UIControl.State.normal)
            optionC.setTitle(allQuestions.list[questionNumber].optionC, for: UIControl.State.normal)
            optionD.setTitle(allQuestions.list[questionNumber].optionD, for: UIControl.State.normal)
            selectedAnswer = allQuestions.list[questionNumber].correctAnswer
        }else{
            let alert = UIAlertController (title: "จบเกม",message: "End of Quiz. Do you want to start over?",preferredStyle: .alert)
            let  restartAction = UIAlertAction (title: "Restart", style: .default, handler: {action in self.restarQuiz()})
            alert .addAction(restartAction)
            present(alert, animated: true, completion: nil)
        }
        updateUI()
    }
    func updateUI(){
        scoreLabel.text = "score: \(score)"
        questionCounter.text = "\(questionNumber + 1)/\(allQuestions.list.count)"
        progressView.frame.size.width = (view.frame.size.width / CGFloat(allQuestions.list.count)) * CGFloat(questionNumber + 1)
    }
    func restarQuiz(){
        score = 0
        questionNumber = 0
        timeCount=11
        updateQuetion()
        
    }
    
}
