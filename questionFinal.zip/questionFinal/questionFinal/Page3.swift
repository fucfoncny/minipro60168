//
//  page3.swift
//  questionFinal
//
//  Created by ict on 15/11/2561 BE.
//  Copyright © 2561 ict. All rights reserved.
//

import Foundation
import UIKit

class Page3: UIViewController {
    
    var randomGroup : Int = 0
    
    let groupArray = ["02","04","03","07"]
    
    @IBOutlet weak var groupShow: UIImageView!
    
    @IBOutlet weak var showLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        changeGroup()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func randomButton(_ sender: UIButton) {
    changeGroup()
        if groupShow.image == UIImage(named: groupArray[0]){
            showLabel.text = "คุณเป็นคนแอบใจร้อน ชอบทางลัด สูตรลัด อยากได้อะไรเร็วๆ ชอบเที่ยว ชอบผจญภัย"
        }else if groupShow.image == UIImage(named: groupArray[1]){
            showLabel.text = "คุณอยากย้อนเวลาหาอดีต ไปพูดอะไรบางอย่างกับตัวเอง หรือใครบางคน ไม่ก็ไปอนาคต"
        }else if groupShow.image == UIImage(named: groupArray[2]){
            showLabel.text = "คุณมีแนวโน้มเป็นคนชอบความสมบูรณ์แบบ เอามันให้หมดเลย"
        }else if groupShow.image == UIImage(named: groupArray[3]){
            showLabel.text = "คุณมีเป็นคนรักธรรมชาติ ชอบท่องเที่ยวหาสิ่งใหม่ๆอยู่เสมอ"
        }
    }
    func changeGroup() {
        randomGroup = Int(arc4random_uniform(3))
        
        groupShow.image = UIImage(named: groupArray[randomGroup])
    
    
}
  override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        changeGroup()
    }


}
