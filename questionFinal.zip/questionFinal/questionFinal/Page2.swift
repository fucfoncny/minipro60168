//
//  page2.swift
//  questionFinal
//
//  Created by ict on 15/11/2561 BE.
//  Copyright © 2561 ict. All rights reserved.
//

import Foundation
import UIKit
class Page2:UIViewController {
    
    var timer = Timer ()
    var timeCount = 5
    
    @IBOutlet weak var showTime: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(page2.processTimer), userInfo: nil, repeats: true)
        
    }
    @objc func processTimer() {
        if timeCount > 0 {
            timeCount -= 1
            showTime.text = String(timeCount)
        }else{
            timer.invalidate()
        }
        if timeCount <= 0 {
            timeCount=0
            showTime.text = String(timeCount)
        }
        showTime.text = String(timeCount)
    }
    
}
