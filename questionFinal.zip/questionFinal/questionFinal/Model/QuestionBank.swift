//
//  QuestionBank.swift
//  questionFinal
//
//  Created by ict on 15/11/2561 BE.
//  Copyright © 2561 ict. All rights reserved.
//

import Foundation

class QuestionBank{
    var list = [Question]()
    
    init(){
        list.append(Question(image: "01", questionText: "ของวิเศษชิ้นมีชื่อว่าอะไร", choiceA: "ขนมปังช่วยเตือน", choiceB: "ขนมปังช่วยจำ", choiceC: "ขนมปังช่วยชีวิต", choiceD: "ขนมปังกันลืม", answer: 2))
        list.append(Question(image: "02", questionText: "ของวิเศษชิ้นนี้มีชื่อว่าอะไร", choiceA: "ประตูไปไหนก็ได้", choiceB: "ประตูกลับบ้าน", choiceC: "ประตูสู่ความจริง", choiceD: "ประตูบ้าน", answer: 1))
        list.append(Question(image: "03", questionText: "ความสามารถของวิเศษชิ้นนี้คืออะไร", choiceA: "เขียนเร็ว", choiceB: "เขียนได้ทุกที่", choiceC: "แก้โจทย์ปัญหาที่แก้ไม่ออก", choiceD: "แก้ลายมือ", answer: 3))
        list.append(Question(image: "04", questionText: "ของวิเศษชิ้นนี้พาไปไหน", choiceA: "โลกแห่งอนาคต", choiceB: "ย้อนอดีต", choiceC: "ไปหาไดโนเสาร์", choiceD: "ถูกทุกข้อ", answer: 4))
        list.append(Question(image: "06", questionText: "ของวิเศษชิ้นนี้มีชื่อว่าอะไร", choiceA: "ห่วงใย", choiceB: "ห่วงใคร", choiceC: "ห่วงผ่านตลอด", choiceD: "ห่วงนะ", answer: 3))
        list.append(Question(image: "07", questionText: "ของวิเศษชิ้นนี้มีชื่อว่าอะไร", choiceA: "บ่อตกกุ้ง", choiceB: "บ่อตกปลาในห้อง", choiceC: "บ่อตกหมึก", choiceD: "บ่อตกหอย", answer: 2))
        list.append(Question(image: "08", questionText: "ความสามารถของวิเศษนี้มีคืออะไร", choiceA: "ดูละคร", choiceB: "ดูการ์ตูน", choiceC: "ดูภาพอดีตและอนาคต", choiceD: "จัดรายการทีวีเอง", answer: 3))
        list.append(Question(image: "09", questionText: "ของวิเศษชิ้นนี้มีชื่อว่าอะไร", choiceA: "ค้อนเตือนความจำ", choiceB: "ค้อนเรียกความรู้", choiceC: "ค้อนเรียกโดเรม่อน", choiceD: "ค้อนทุบทุกอย่าง", answer: 1))
        list.append(Question(image: "10", questionText: "ของวิเศษชิ้นนี้มีชื่อว่าอะไร", choiceA: "เครื่อตกแต่งน้ำแข็ง", choiceB: "เครื่องตัดต้นไม้", choiceC: "เครื่องตกแต่งบ้าน", choiceD: "เครื่องตกแต่งพื้น", answer: 1))
        list.append(Question(image: "12", questionText: "ของวิเศษชิ้นนี้มีชื่อว่าอะไร", choiceA: "ผ้าคลุมนอน", choiceB: "ผ้าคลุมเสื้อ", choiceC: "ผ้าคลุมกาลเวลา", choiceD: "ผ้าคลุมบินได้", answer: 3))
    }
}
