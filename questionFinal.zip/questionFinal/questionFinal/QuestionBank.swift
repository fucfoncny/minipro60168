//
//  QuestionBank.swift
//  questionFinal
//
//  Created by ict on 15/11/2561 BE.
//  Copyright © 2561 ict. All rights reserved.
//

import Foundation
class QuestionBank{

var list = [Question]()
init(){
    list.append(Question(image: "thai", questionText: "ภาพนี้คืออะไร", choiceA: "1. ไก่", choiceB: "2. เป็ด", choiceC: "3. ปลา", choiceD: "4. หมู", answer:4 ))
    list.append(Question(image: "all", questionText: "ภาพนี้คือใคร", choiceA: "1. หมิง", choiceB: "2. แอล", choiceC: "3. ป๊อป", choiceD: "4. ฝน", answer:2 ))
    list.append(Question(image: "color", questionText: "ภาพนี้คือที่ไหน", choiceA: "1. กรุงเทพ", choiceB: "2. ลอนดอน", choiceC: "3. ปารีส", choiceD: "4. เบลเยี่ยม", answer:1 ))
    list.append(Question(image: "all", questionText: "ภาพนี้มีกี่คน", choiceA: "1. 2คน", choiceB: "2. 3คน", choiceC: "3. 4คน", choiceD: "4. 5คน", answer:1 ))
    list.append(Question(image: "thai", questionText: "ภาพนี้คืออะไร", choiceA: "1. ปลา", choiceB: "2. กุ้ง", choiceC: "3. เห็ด", choiceD: "4. นก", answer:3 ))
    list.append(Question(image: "color", questionText: "ภาพนี้คืออะไร", choiceA: "1. ไก่", choiceB: "2. เป็ด", choiceC: "3. ปลา", choiceD: "4. หมู", answer:4 ))
    list.append(Question(image: "thai", questionText: "ภาพนี้คือใคร", choiceA: "1. หมิง", choiceB: "2. แอล", choiceC: "3. ป๊อป", choiceD: "4. ฝน", answer:2 ))
    list.append(Question(image: "color", questionText: "ภาพนี้คือที่ไหน", choiceA: "1. กรุงเทพ", choiceB: "2. ลอนดอน", choiceC: "3. ปารีส", choiceD: "4. เบลเยี่ยม", answer:1 ))
    list.append(Question(image: "all", questionText: "ภาพนี้มีกี่คน", choiceA: "1. 2คน", choiceB: "2. 3คน", choiceC: "3. 4คน", choiceD: "4. 5คน", answer:1 ))
    list.append(Question(image: "thai", questionText: "ภาพนี้คืออะไร", choiceA: "1. ปลา", choiceB: "2. กุ้ง", choiceC: "3. เห็ด", choiceD: "4. นก", answer:3 ))
    
    
}

}
